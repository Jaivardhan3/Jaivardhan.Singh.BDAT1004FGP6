from django.contrib import admin
from .models import SuicidesInIndia

class DataAdmin(admin.ModelAdmin):
    list_display = ('state', 'year', 'type_code', 'type', 'gender', 'age_group', 'total')

# Register your models here.
admin.site.register(SuicidesInIndia, DataAdmin)

