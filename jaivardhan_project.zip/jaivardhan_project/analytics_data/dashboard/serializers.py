from rest_framework import serializers
from dashboard.models import SuicidesInIndia

class DataSerializer(serializers.ModelSerializer):
    class Meta:
        model = SuicidesInIndia 
        fields=('state', 'year', 'type_code', 'type', 'gender', 'age_group', 'total')