from django.db import models

# Create your models here.
class SuicidesInIndia(models.Model):
    state = models.CharField(max_length=255, db_collation='utf8_bin')
    year = models.TextField()  # This field type is a guess.
    type_code = models.CharField(max_length=255, db_collation='utf8_bin')
    type = models.CharField(max_length=255, db_collation='utf8_bin')
    gender = models.CharField(max_length=255, db_collation='utf8_bin')
    age_group = models.CharField(max_length=255, db_collation='utf8_bin')
    total = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'Suicides_in_India'

    def __str__(self):
        return self.state
