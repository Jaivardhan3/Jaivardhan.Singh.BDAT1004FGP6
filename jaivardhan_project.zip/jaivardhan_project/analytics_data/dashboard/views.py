from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from .models import SuicidesInIndia
from .serializers import DataSerializer
import requests

# Create your views here.

#Get data from database
# def index(request):
#     suicidesinindia = SuicidesInIndia.objects.all()
#     context = {'suicidesinindia': suicidesinindia}
#     return render(request, 'index.html', context)

@csrf_exempt
def dataApi(request):
    if request.method=='GET':
        allData = SuicidesInIndia.objects.all()
        allData_serializers = DataSerializer(allData,many=True)
        return JsonResponse(allData_serializers.data, safe=False)

#Get data from api
def index(request):
    result = requests.get('http://127.0.0.1:8000/MyData')
    response = result.json()
    return render(request, 'index.html', {'response':response})