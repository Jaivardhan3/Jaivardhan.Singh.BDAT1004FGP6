import mysql.connector
from mysql.connector.constants import ClientFlag

class Database:
    # Connection to database
    @staticmethod
    def connect_data_dbs():
        config = {
            'user': 'root',
            'password': 'mozu8866262522',
            'host': '34.133.44.157',
            'client_flags': [ClientFlag.SSL],
            'ssl_ca': 'ssl/server-ca.pem',
            'ssl_cert': 'ssl/client-cert.pem',
            'ssl_key': 'ssl/client-key.pem'
        }
        config['database'] = 'SuicidesInIndia'
        mydb = mysql.connector.connect(**config)
        return mydb