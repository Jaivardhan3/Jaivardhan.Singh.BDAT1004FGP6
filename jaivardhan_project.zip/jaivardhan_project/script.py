import datadotworld as dw
import numpy as np
from lib.database import Database as MyDatabase
from apscheduler.schedulers.blocking import BlockingScheduler

def process_data_set():

    results = dw.query('rajanand/suicides-in-india', 'SELECT * FROM suicides_in_india')

    df = results.dataframe

    df['new'] = df.apply(lambda r: tuple(r), axis=1).apply(np.array)

    my_connection = MyDatabase.connect_data_dbs()
    mycursor = my_connection.cursor()
    mycursor.execute("SELECT * FROM Suicides_in_India")

    myresult = mycursor.fetchall()

    for x in myresult:
        for val in df['new']:
            if x[2] == val[1]:
                print("Data already exists")
            else:
                state = val[0]
                year = val[1]
                type_code = val[2]
                type = val[3]
                gender = val[4]
                age_group = val[5]
                total = val[6]

                sql = ("INSERT INTO Suicides_in_India(state, year, type_code, type, gender, age_group, total)""VALUES (%s, %s, %s, %s, %s, %s, %s)")
                
                suicides_details = (state, year, type_code, type, gender, age_group, total)
                try:
                    mycursor.execute(sql, suicides_details)
                    my_connection.commit()
                except:
                    my_connection.rollback()

                print("Data inserted")

    my_connection.close()

scheduler = BlockingScheduler()
scheduler.add_job(process_data_set, 'interval', hours=24)
scheduler.start()